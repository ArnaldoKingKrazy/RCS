<di class="col-12 text-center">
	<div class="text-center">
	<img src="PICTURES/loading.gif" width="50%">
</div>
<div>
	<h4 class="text-center">Espere Mientras Terminamos su Solicitud...</h4>
</div>
</di>
