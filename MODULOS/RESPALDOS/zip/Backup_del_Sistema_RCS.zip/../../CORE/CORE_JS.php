    <script src="CORE/JS/popper.min.js"></script>
    <script src="CORE/JS/bootstrap.min.js"></script>
    <script src="CORE/JS/lightbox.js"></script>
    <script src="CORE/JS/scripts_menu.js"></script>
    <script src="ADMIN/admin.js"></script>
    <script src="AXIOS/srcs.js"></script>
    <script src="AGRONOMO/script_agronomo.js"></script>
    <script src="MODULOS/GALERIA/galeria.js"></script>
    <script src="MODULOS/ABOUT/about.js"></script>

    


