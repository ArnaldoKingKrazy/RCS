<div class="row mx-auto">
  <div class="col-12 text-center ">
    <div class="alert alert-primary sombra mx-auto" style="width: 70%">
      <strong>¡Seleccione un tipo de Producto para Habilitar la lista Correspondiente!</strong>
    </div>
  </div>
</div>