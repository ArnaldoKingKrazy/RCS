<!DOCTYPE html>
<html>
<head>
	<title>Pruebas</title>
	<script type="text/javascript">

		// convert a latitude to deg and decimal minutes
		  function lat2dm(input){
               if (input > 0){
                  return (deg2dm(input)+"N")
               }else{
                  return (deg2dm(input)+"S")
               }
            }


            // convert a latitude to deg and decimal minutes
            function lon2dm(input){
               if (input > 0){
                  return (deg2dm(input)+"E")
               }else{
                  return (deg2dm(input)+"W")
               }
            }

            // converts decimal degrees to degrees and decimal minutes
            // input is a float, return value a string
 			function deg2dm(input) {
               var cdeg
               var cmin
               var deg = Math.floor(Math.abs(input))
               var min = (Math.abs(input) - deg)*60

               if (deg < 10) {
                	cdeg = "0"+deg 
            	}else{
               		cdeg = ""+deg 
               }
 
               if (min < 10){ 
               		cmin = "0"+min.toFixed(3) 
               }else {
               		cmin = ""+min.toFixed(3) 
               }
               return(cdeg+"-"+cmin)
            }
 
            
        // convert a latitude to deg-min-sec
            function lat2dms(input){
               if (input > 0){
                  return (deg2dms(input)+"N")
               }else {
                  return (deg2dms(input)+"S")
               }
            }
 
             
 
            // convert a latitude to deg-min-sec
            function lon2dms(input){
               if (input > 0){
                  return (deg2dms(input)+"E")
               }else{
                  return (deg2dms(input)+"W")
               }
            }


 function deg2dms(input) {
               var cdeg
               var cmin    
               var csec 
               var temp = Math.abs(input)
               var deg = Math.floor(temp)
               var min = Math.floor((temp - deg)*60)
               var sec = (((temp-deg)*60)-min)*60
               if (deg < 10) { cdeg = "0"+deg }
               else {cdeg = ""+deg }

               if (min < 10) {
                	cmin = "0"+min
                 }else {
                 	cmin = ""+min 
                 }
 
            
 
               if (sec < 10) { 
               		csec = "0"+sec.toFixed(1)
               		 }else {
               		 csec = ""+sec.toFixed(1) 
               		}
               return(cdeg+"º "+cmin+"' "+csec+"'' ")
            }
 

	</script>
</head>
<body>

<script type="text/javascript">
	
	alert(lon2dms(-67.58363810088443));
	alert(lat2dms(10.233843084608255));
67.583336111111
alert()


</script>



<?php 
function DMStoDD($deg,$min,$sec)
{

    // Converting DMS ( Degrees / minutes / seconds ) to decimal format
    return $deg+((($min*60)+($sec))/3600);
}    

echo DMStoDD(67,35,0.01);
 ?>


</body>
</html>