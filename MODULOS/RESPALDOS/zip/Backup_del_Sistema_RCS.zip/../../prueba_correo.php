<?php 
include"INCLUDES/CONEXION.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'includes/Exception.php';
require 'includes/PHPMailer.php';
require 'includes/SMTP.php';

$correo_destino='arnaldoruizpersonal@gmail.com';
$nombre_destino="Proyecto MOE";


$mail = new PHPMailer(true);
try {

    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = $mail_Host;                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = $mail_Username;                     //SMTP username
    $mail->Password   = $mail_Password;                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                        

    //Recipients
    $mail->setFrom($mail_setFrom_1, $mail_setFrom_2);

    $mail->addAddress($correo_destino, $nombre_destino);     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Proyecto MOE';
    $mail->Body    = '
    	<b>Ante Todo un Coordial Saludo de parte de Todos en proyectomoe.com</b><br>
    	<b>Notificamos Mediante este Correo:</b>
 
    	<h5>Que Usted Se Registro Correctamente.<h5><br>
    	<h2>Bienvenido</h2>
    ';
    $mail->AltBody = 'https://www.proyectomoe.com';

    $mail->send();
    echo "Correo Enviado";
} catch (Exception $e) {
    // Aqui para notificar fallo al enviar el correro
}
 ?>