<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
<title>Calculadora - conversión de coordenadas</title>
 <script type="text/javascript" src="http://xxxxxxxxxx.xxxx/functions/usng.js"></script>
  <script type="text/javascript">
  // convert a latitude to deg and decimal minutes
 
            function lat2dm(input) {
 
               if (input > 0) {
 
                  return (deg2dm(input)+"N")
 
               }
 
               else {
 
                  return (deg2dm(input)+"S")
 
               }
 
            }
 
             
 
            // convert a latitude to deg and decimal minutes
 
            function lon2dm(input) {
 
               if (input > 0) {
 
                  return (deg2dm(input)+"E")
 
               }
 
               else {
 
                  return (deg2dm(input)+"W")
 
               }
 
            }
 
             
 
            // converts decimal degrees to degrees and decimal minutes
 
            // input is a float, return value a string
 
            function deg2dm(input) {
 
               var cdeg
 
               var cmin
 
               var deg = Math.floor(Math.abs(input))
 
               var min = (Math.abs(input) - deg)*60
 
            
 
               if (deg < 10) { cdeg = "0"+deg }
 
               else {cdeg = ""+deg }
 
               if (min < 10) { cmin = "0"+min.toFixed(3) }
 
               else {cmin = ""+min.toFixed(3) }
 
            
 
               return(cdeg+"-"+cmin)
 
            }
 
            
 
            
 
        // convert a latitude to deg-min-sec
 
            function lat2dms(input) {
 
               if (input > 0) {
 
                  return (deg2dms(input)+"N")
 
               }
 
               else {
 
                  return (deg2dms(input)+"S")
 
               }
 
            }
 
             
 
            // convert a latitude to deg-min-sec
 
            function lon2dms(input) {
 
               if (input > 0) {
 
                  return (deg2dms(input)+"E")
 
               }
 
               else {
 
                  return (deg2dms(input)+"W")
 
               }
 
            }
 
            
 
            // converts decimal degrees to deg-min-sec
 
            // input is a float, return value a string
 
            function deg2dms(input) {
 
               var cdeg
 
               var cmin    
 
               var csec
 
            
 
               var temp = Math.abs(input)
 
               var deg = Math.floor(temp)
 
               var min = Math.floor((temp - deg)*60)
 
               var sec = (((temp-deg)*60)-min)*60
 
            
 
            
 
               if (deg < 10) { cdeg = "0"+deg }
 
               else {cdeg = ""+deg }
 
            
 
               if (min < 10) { cmin = "0"+min }
 
               else {cmin = ""+min }
 
            
 
               if (sec < 10) { csec = "0"+sec.toFixed(1) }
 
               else {csec = ""+sec.toFixed(1) }
 
            
 
               return(cdeg+"-"+cmin+"-"+csec)
 
            }
 
        </script>
  
 </head>
<body onload="cambio1()">
<script type="text/javascript"> 
                     
                    
 
                function cambio1(){
 
                        pointy=<? echo $_GET["gradoslat"]; ?>;
 
                        pointx=<? echo $_GET["gradoslon"]; ?>;
 
                         
                        var northamerica=1
 
                        var ngCoords = LLtoUSNG(pointy,pointx, 5);
 
                        var mgrsCoords = LLtoMGRS(pointy,pointx, 5);
 
                        var utmcoords=[]
 
                        var zone
 
                        LLtoUTM(pointy,pointx,utmcoords,0)
 
                        zone = utmcoords[2]
 
                    
 
                        if (pointy>13 && pointy<90 && ((pointx<-46 && pointx>-180) || (pointx>169 && pointx<180))) { 
 
                            northamerica = 1
 
                        }
 
                        else {
 
                            northamerica = 0
 
                        }
 
                        
 
                        var utmx = utmcoords[0];
 
                        var utmy = utmcoords[1];
 
                        if (utmy < 0) { utmy+=10000000; }
 
 
 
        
 
                        document.getElementById("resultados").style.display="block";
 
                        document.getElementById("res").innerHTML= zone + " " + UTMLetterDesignator(pointy)+" " + utmx.toFixed(0) + " " + utmy.toFixed(0);
 
                        document.getElementById("res2").innerHTML=LLtoMGRS(pointy,pointx,4);
 
                        cres3=lat2dms(pointy) + ", " + lon2dms(pointx);
 
                        cres3=cres3.replace(/-/g," ");
 
                        cres3=cres3.replace("W"," O");
 
                        cres3=cres3.replace("E"," E");
 
                        cres3=cres3.replace("N"," N");
 
                        cres3=cres3.replace("S"," S");
 
                        document.getElementById("res3").innerHTML=cres3;
 
                        
 
                        cres4=lat2dm(pointy) + ", " + lon2dm(pointx);
 
                        cres4=cres4.replace(/-/g," ");
 
                        cres4=cres4.replace("W"," O");
 
                        cres4=cres4.replace("E"," E");
 
                        cres4=cres4.replace("N"," N");
 
                        cres4=cres4.replace("S"," S");
 
                        document.getElementById("res4").innerHTML=cres4;
 
                        document.getElementById("res5").innerHTML=pointy+", "+pointx;
 
                        initialize();
 
                        
 
                    }
 
                </script> <!--//-->
<form name='inputboxes'>
<div id="resultados" ><table><tr><td>UTM</td><td><span id="res"></span></td></tr><tr><td>MGRS</td><td><span id="res2"></span></td></tr><tr><td>G M S.s</td><td><span id="res3"></span></td></tr><tr><td>G M.m</td><td><span id="res4"></span></td></tr><tr><td>G.g</td><td><span id="res5"></span></td></tr></table></div></form>

</body></html>

<script type="text/javascript">
      alert(lon2dms(-67.58363810088443));
</script>